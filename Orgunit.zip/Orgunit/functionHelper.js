function generateOrgunitTemplate(item, id, langue, pays) {
  if (!item) {
      return '<div class="col">Aucun organisme de formation trouvé.</div>';
  }
  var itemID = item.cdm_orgunit_1_id;
  var thisData = JSON.parse(item.cdm_orgunit_27_officialLanguage);
  console.log(thisData);

  var itemLang = '';
  if (Array.isArray(thisData)) {
      var langSliced, fullLanguageNames;
      if (thisData[0].hasOwnProperty('lang')) {
          var langs = thisData.map(langObj => langObj.lang);
          var normalizedLangs = langs.map(lang => normalize_language(lang));
          langSliced = normalizedLangs.slice(0, 2);
          fullLanguageNames = langSliced.map(code => language_code_to_name(code, langue));
      } else {
          langSliced = thisData.slice(0, 2);
          fullLanguageNames = langSliced.map(code => language_code_to_name(code, langue));
      }
      itemLang = fullLanguageNames.join(", ");
  }

  var itemLogo = item.cdm_orgunit_20_logo ? item.cdm_orgunit_20_logo : '/wp-content/uploads/2022/07/blank-img.png';

  var itemImage = item.cdm_orgunit_18_urlImageOrgUnit ? item.cdm_orgunit_18_urlImageOrgUnit : '/wp-content/plugins/parene/img/orgunit/orgunit-photo-general.png';

  var nameData = JSON.parse(item.cdm_orgunit_2_name);
  var itemTitle = nameData.find(nameObj => nameObj.text).text;

  var itemPaysCode = item.cdm_orgunit_13_1_2_3_country || '';
  var itemPays = getCountryName(itemPaysCode, pays);

  var itemLink = '/organismes-de-formation/detail/?id=' + itemID;

  var HTML_item_top_header = `
              <div class="align-self-center">
                  <div class="badge bg-bleu">${itemLang}</div>
              </div>
              <div class="col">
                  <img class="logo-product-small float-end item-top-badge-right-img" src="${itemLogo}">
              </div>`;

  var HTML_item_content = `
              <div class="item-content-txt item-pays">${itemPays}</div>
              `;

  

  return `
  <div class="col-md-6 col-lg-4 mb-5">
    <div class="one-product h-100 rounded shadow-border">
        <div class="item-top">
            <div class="item-top-wrapper text-center p-3 pb-2">
                <div class="item-top-header mb-3">
                    ${HTML_item_top_header}
                </div>
                <div class="item-top-img-wrapper mb-2" data-id="${itemID}">
                    <img class="item-top-img" src="${itemImage}">
                    ${HTML_item_top_content}
                </div>
            </div>
        </div>
        <div class="item-content">
            <div class="item-content-wrapper text-center pt-4 px-4 pb-3">
                <div class="item-content-box">
                    <div class="item-title ${CSS_item_title}">${itemTitle}</div>
                    ${HTML_item_content}
                </div>
                <div class="item-content-detailButton">
                    <a class="parene-btn bg-bleu btn-small" href="${itemLink}" role="button">Plus de détails</a>
                </div>
                <hr>
            </div>
        </div>
    </div>
</div>`;
}
  const renderCompleteData = (data) => {
    if (data.hits && data.hits.hits) {
    var hits = data.hits.hits;
    var totalResult = data.hits.total.value;
    console.log("je suis ici data",data)
    console.log("imaaaaaaaaaaaaaaaaaaaaaaaaaaaaad", hits);
    var templates = hits.map((hit) => generateOrgunitTemplate(data.hits.hits[0]._source, data.hits.hits[0]._id));
  
    console.log("hit._source", hit._source);
    console.log("hit._id", hit._id);
    console.log("template", templates);
    completeTemplate = templates.join("");
    resultsContainer.innerHTML = completeTemplate;
    
    
    total = Math.ceil(totalResult / 12);
    getPaginationList(page, total).then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      response.json().then(res => {
        
        const content = JSON.parse(res);
        const paginationHTML = rednerPaginationElement(content);
  
        pagination.innerHTML = paginationHTML;
        allLink = pagination.getElementsByClassName('page-numbers');
        //console.log("the page we get : ", allLink);
        allLink.forEach(link => {
          link.addEventListener("click", (e) => {
            e.preventDefault();
            var currentElement = e.target;
            allLink.forEach(res => {
              res.classList.remove('current');
            })
            currentElement.classList.add('current');
            page = parseInt(currentElement.innerText.replace(/[^0-9]/g, ""));
            console.log("Données reçues :", data);
            renderCompleteData(data);
            alert(page);
            makeAndPrintRequest(createRequestBodyFunction());
            //getAllOrgunitWithCoposedRequest()
          })
        })
      })
      // Read the response body as text
    })
      .catch(error => {
        console.error('Fetch error:', error);
      });
  }else{
    console.error("Les données hits ne sont pas définies dans la réponse.");
  }
  }
  
  
  
  const rednerPaginationElement = (listText) => {
    const parser = new DOMParser();
    // Create a new DOMParser
    // Parse the HTML string into a DocumentFragment
    const docFragment = parser.parseFromString(listText.data, 'text/html');
  
    // Extract the children (HTML elements) from the DocumentFragment
    const elements = Array.from(docFragment.body.children);
    elements.forEach(element => {
      element.addEventListener('click', function () {
        // Your event handling code here
        e.preventDefault();
        var currentElement = e.target;
        allLink.forEach(res => {
          res.classList.remove('current');
        })
        currentElement.classList.add('current');
      });
    });
    const elementsAsText = elements.map(element => element.outerHTML).join('');
    return elementsAsText;
  }
  

  const renderSearchedname = (names, nameSuggestionContainer) => {
    nameSuggestionContainer.style.display = "block";
    nameSuggestionContainer.innerHTML = "";
  
    // Utilisez un ensemble pour stocker les auteurs déjà ajoutés
    const addedNames = new Set();
  
    names.forEach((name) => {
      const Names = name._source.pr_cdm_name.split('|');
  
      Names.forEach((authorName) => {
        // Vérifiez si l'auteur n'est pas vide et n'a pas été ajouté auparavant
        const trimmedAuthorName = authorName.trim();
        if (trimmedAuthorName !== "" && !addedNames.has(trimmedAuthorName)) {
          allNames.push(name);
          addedNames.add(trimmedAuthorName);
  
          const element = document.createElement("li");
          element.textContent = trimmedAuthorName;
  
          element.addEventListener("click", async (e) => {
            e.stopPropagation();
            page = 1;
            nameInput.value = trimmedAuthorName;
            nameSuggestionContainer.innerHTML = "";
            nameSuggestionContainer.style.display = "none";
            await getAllOrgunitWithCoposedRequest();
          });
  
          if (element.textContent !== '') {
            element.classList.add("list-group-item", "list-group-item-action");
            nameSuggestionContainer.appendChild(element);
          }
        }
      });
    });
  }
  
  const renderName = (names, nameSuggestionContainer) => {
    // Utilisez un ensemble pour stocker les auteurs déjà ajoutés
    const addedNames = new Set();
  
    names.forEach((name) => {
      const authorNames = name._source.pr_cdm_name.split('|');
  
      authorNames.forEach((authorName) => {
        // Vérifiez si l'auteur n'est pas vide
        const trimmedAuthorName = authorName.trim();
        if (trimmedAuthorName !== "") {
          // Ajoutez l'auteur à l'ensemble addedNames même s'il existe déjà
          addedNames.add(trimmedAuthorName);
  
          const element = document.createElement("li");
          element.textContent = trimmedAuthorName;
  
          element.addEventListener('click', async (e) => {
            e.stopPropagation();
            page = 1;
            nameInput.value = trimmedAuthorName;
            resultsContainer.innerHTML = '';
            nameSuggestionContainer.style.display = "none";
            const orgunit = await getAllOrgunitWithCoposedRequest();
          });
  
          // Vérifiez si l'élément existe déjà dans titles, si oui, n'ajoutez pas la classe
          if (!names.some((existingTitle) =>
            existingTitle._source.pr_resource_author.includes(trimmedAuthorName)
          )) {
            element.classList.add("list-group-item", "list-group-item-action");
            nameSuggestionContainer.appendChild(element);
          }
        }
      });
    });
  }
  
  /////////Keyword
  
  const renderkeywords = (keywords, keywordSuggestionsContainer) => {
    // Utilisez un ensemble pour stocker les auteurs déjà ajoutés
    const addedKeyword = new Set();
  
    keywords.forEach((keyword) => {
      const KeywordNames = keyword._source.cdm_orgunit_17_searchword.split('|');
  
      KeywordNames.forEach((KeywordName) => {
        // Vérifiez si l'auteur n'est pas vide
        const trimmedAuthorName = KeywordName.trim();
        //if (trimmedAuthorName !== "") {
        // Ajoutez l'auteur à l'ensemble addedKeyword même s'il existe déjà
        addedKeyword.add(trimmedAuthorName);
  
        const element = document.createElement("li");
        element.textContent = trimmedAuthorName;
  
        element.addEventListener('click', async (e) => {
          e.stopPropagation();
          page = 1;
          keywordInput.value = trimmedAuthorName;
          resultsContainer.innerHTML = '';
          keywordSuggestionsContainer.style.display = "none";
          const orgunit = await getAllOrgunitWithCoposedRequest();
        });
  
        // Vérifiez si l'élément existe déjà dans titles, si oui, n'ajoutez pas la classe
        if (!keywords.some((existingTitle) =>
          existingTitle._source.pr_resource_keyword.includes(trimmedAuthorName)
        )) {
          element.classList.add("list-group-item", "list-group-item-action");
          keywordSuggestionsContainer.appendChild(element);
        }
        // }
      });
    });
  }
  
  
  /**
   * 
   * @param {*} author 
   * @param {*} listAuthors 
   * @return boolean
   */
  const filterName = (author, listAuthors) => {
    var find = false;
    listAuthors.forEach(auth => {
      if (auth._source.pr_cdm_name == author._source.pr_cdm_name) {
        find = true;
      }
    })
    return find;
  }

  // STUDY FEILD
  
  const renderSearchedStudyFeild = (studyfeilds, studyfeildSuggestionContainer) => {
    studyfeildSuggestionContainer.style.display = "block";
    studyfeildSuggestionContainer.innerHTML = "";
  
    studyfeilds.forEach((editeur) => {
      allStudy.push(editeur);
      var element = document.createElement("li");
  
      // Divisez le texte par le caractère "|"
      const editeurText = editeur._source.cdm_orgunit_24_studyfields.text;
      const editeurArray = editeurText.split('|');
  
      // Ajoutez chaque éditeur en tant qu'élément distinct dans la liste de suggestions
      editeurArray.forEach(editeurValue => {
        element.textContent = editeurValue;
        element.classList.add("list-group-item", "list-group-item-action");
        element.addEventListener("click", async (e) => {
          e.stopPropagation();
          page = 1;
          editeurInput.value = editeurValue;
          studyfeildSuggestionContainer.innerHTML = "";
          studyfeildSuggestionContainer.style.display = "none";
          await getAllOrgunitWithCoposedRequest();
        });
  
        if (editeurValue !== "") {
          studyfeildSuggestionContainer.appendChild(element);
        }
      });
  
      
    })
  };
  
  
  const renderStudyFeild = (editeurs, studyfeildSuggestionContainer) => {
    editeurs.forEach(editeur => {
      allStudyFeild.push(editeur);
      if (editeur._source.cdm_orgunit_24_studyfields.text !== '') {
  
        // Divisez le texte par le caractère "|"
        const editeurText = editeur._source.cdm_orgunit_24_studyfields.text;
        const editeurArray = editeurText.split('|');
  
        editeurArray.forEach(editeurValue => {
          var element = document.createElement("li");
          var edit = editeur;
          allStudyFeild.push(editeur);
          element.addEventListener('click', async (e) => {
            e.stopPropagation();
            page = 1;
            
            editeurInput.value = editeurValue;
            resultsContainer.innerHTML = '';
            studyfeildSuggestionContainer.style.display = "none";
            const orgunit = await getAllOrgunitWithCoposedRequest();
          });
  
          element.textContent = editeurValue;
          element.classList.add("list-group-item", "list-group-item-action");
          studyfeildSuggestionContainer.appendChild(element);
        });
      }
    })
  };
  
  
  
  
  
  /**
   * 
   * @param {*} editeur 
   * @param {*} listEditeur 
   * @return boolean
   /
  const filterEditeur = (editeur , listEditeur)=>{
    var find = false ; 
    listEditeur.forEach(edit => {
      if(edit._source.cdm_orgunit_17_searchword == editeur._source.cdm_orgunit_17_searchword){
        find = true ; 
      }
    })
    return find ;
  }
  */
 //// DIPLOMA
  const renderSearchedDiplome = (titles, diplomasSuggestionContainer) => {
    diplomasSuggestionContainer.style.display = "block";
  
    diplomasSuggestionContainer.innerHTML = "";
  
    titles.forEach((title) => {
      allTitles.push(title);
      var element = document.createElement("li");
      element.textContent = title._source.cdm_orgunit_26_diplomas.text;
      
      element.classList.add("list-group-item", "list-group-item-action");
      element.addEventListener("click", async (e) => {
        e.stopPropagation();
        page = 1;
        titleInput.value = title._source.cdm_orgunit_26_diplomas.text;
        diplomasSuggestionContainer.innerHTML = "";
        diplomasSuggestionContainer.style.display = "none";
        await getAllOrgunitWithCoposedRequest();
      });
  
      diplomasSuggestionContainer.appendChild(element);
    })
  }
  
  const renderDiplome = (titles, diplomasSuggestionContainer) => {
  
    titles.forEach(element => {
      titles.forEach((title) => {
        allTitles.push(titles);
        var element = document.createElement("li");
        var tit = title;
  
        element.addEventListener('click', async (e) => {
          e.stopPropagation();
          page = 1;
          
          titleInput.value = tit._source.cdm_orgunit_26_diplomas.text;
          resultsContainer.innerHTML = '';
          diplomasSuggestionContainer.style.display = "none";
          const orgunit = await getAllOrgunitWithCoposedRequest();
        })
        element.textContent = title._source.cdm_orgunit_26_diplomas.text;
        element.classList.add("list-group-item", "list-group-item-action");
        diplomasSuggestionContainer.appendChild(element);
      });
    })
  
  }
  
  
  /*
  
  /**
   * 
   * @param {*} title 
   * @param {*} listTitle
   * @return boolean
   /
  const filterTitle = (title , listTitle)=>{
    var find = false ; 
    listTitle.forEach(tit => {
      if(tit._source.pr_resource_title == title._source.pr_resource_title){
        find = true ; 
      }
    })
    return find ;
  }
   
   */
  
  const renderSearchedKeywords = (titles, keywordSuggestionsContainer) => {
    keywordSuggestionsContainer.style.display = "block";
    keywordSuggestionsContainer.innerHTML = "";
  
    // Utilisez un ensemble pour stocker les auteurs déjà ajoutés
    const addedNames = new Set();
  
    titles.forEach((title) => {
      const authorNames = title._source.pr_resource_keyword.split('|');
  
      authorNames.forEach((authorName) => {
        // Vérifiez si l'auteur n'est pas vide et n'a pas été ajouté auparavant
        const trimmedAuthorName = authorName.trim();
        //if (trimmedAuthorName !== "" && !addedNames.has(trimmedAuthorName)) {
        allKeyWords.push(title);
        addedNames.add(trimmedAuthorName);
  
        const element = document.createElement("li");
        element.textContent = trimmedAuthorName;
  
        element.addEventListener("click", async (e) => {
          e.stopPropagation();
          page = 1;
          keywordInput.value = trimmedAuthorName;
          keywordSuggestionsContainer.innerHTML = "";
          keywordSuggestionsContainer.style.display = "none";
          await getAllOrgunitWithCoposedRequest();
        });
  
        if (element.textContent !== '') {
          element.classList.add("list-group-item", "list-group-item-action");
          keywordSuggestionsContainer.appendChild(element);
        }
        //}
      });
    });
  }
  
  