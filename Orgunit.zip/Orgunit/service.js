const ApiUrl = "https://wei.parene.org/wp-json/elastic/v1/orguinits";
const PaginationApi = "https://wei.parene.org/wp-json/pagination/pagination";



const fetchOrgunitDate = async (requestBody) => {
  return fetch(ApiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json', // Set the content type if sending JSON data
    },
    body: JSON.stringify(requestBody), // JSON data to send in the request body
  })
}
const getPaginationList = async (current, total) => {
  const requestBody = {
    total: total,
    current: current,
    base: "orgunit" ///  a revien
  }
  return fetch(PaginationApi,
    {
      headers: {
        "Content-Type": "application/json",
        // Specify that you expect JSON data
      },
      method: "POST",
      body: JSON.stringify(requestBody),
    }
  )
}

// ICI LES SERVICES DE SUGGESTION

// 1 : RECHERCHE PAR NOM

const getNomsService = async (requestBody, lastDoc) => {
  requestBody._source = "pr_cdm_name",
    requestBody.size = 1000;
  requestBody.search_after = lastDoc.sort;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];


  var requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
}

const searchNomsService = async (requestBody) => {

  console.log("the request body in search Authors service: ", requestBody);

  requestBody._source = ["pr_cdm_name"];

  requestBody.size = 1000;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];

  const requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions).then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    console.log("THIS IS THE RESPONSE :", response);
    return response.json();
  })

}


// 2 : RECHERCHE PAR KEY WORD

const searchKeywordService = async (requestBody) => {
  requestBody._source = ["cdm_orgunit_17_searchword"];
  requestBody.size = 100;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];

  var requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };
  return await fetch(ApiUrl, requestOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
}
const getKeywordScroll = async (requestBody, lastDoc) => {
  requestBody._source = "cdm_orgunit_17_searchword",
    requestBody.size = 50;
  requestBody.search_after = lastDoc.sort;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];


  var requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
}


const GetKeywords = async (lastKeyWord) => {

}

//3 : RECHERCHE PAR DOMAIN

const searchDomainService = async (requestBody) => {
  requestBody._source = ["cdm_orgunit_24_studyfields.text"];

  requestBody.size = 12;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];

  const requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions).then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    console.log("THIS IS THE RESPONSE :", response);
    return response.json();
  })
}

const getDomainService = async (requestBody, lastDoc) => {
  requestBody._source = "cdm_orgunit_24_studyfields.text",
    requestBody.size = 12;
  requestBody.search_after = lastDoc.sort;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];


  var requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
}

// 4: RECHERCHE PAR DIPLOME

const searchDiplomeService = async (requestBody) => {
  requestBody._source = ["cdm_orgunit_26_diplomas.text"];

  requestBody.size = 30;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];

  const requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions).then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    console.log("THIS IS THE RESPONSE :", response);
    return response.json();
  })
}



const getDiplomeService = async (requestBody, lastDoc) => {
  requestBody._source = "cdm_orgunit_26_diplomas.text",
    requestBody.size = 12;
  requestBody.search_after = lastDoc.sort;
  requestBody.sort = [
    { "id_document.keyword": "asc" }
  ];


  var requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
    redirect: "follow",
  };

  return await fetch(ApiUrl, requestOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })

}