window.onload;
//alert("hello") ; 
window.onload = async function () {
  const delay = 200000000000000;
  //get all input element 
  var debounceTimer;

  window.page = 1;
  console.log("Page: ", window.page);
  console.log("Total Page: ", window.totalPage);
  window.resultsContainer = document.getElementById("archives-content");
  window.pagination = document.getElementById("pagination");


  window.totalResult = 12;
  window.total = 1;
  //Main search 
  window.query_stringInput = document.getElementById("principalSearch");

  window.nameInput = document.getElementById("nameSearch");
  window.descriptionInput = document.getElementById("descriptionSearch");
  window.typeInput = document.getElementById("typeSearch");
  window.countryInput = document.getElementById("countrySearch");
  window.cityInput = document.getElementById("citySearch");
  window.searchwordInput = document.getElementById("searchwordSearch");
  window.studyfeildInput = document.getElementById("studyFieldsSearch");
  window.diplomeInput = document.getElementById("diplomasSearch");
  window.languageInput = document.getElementById("languageSearch");


  window.allNoms = [];
  window.allKeywords = [];
  window.allStudyFeild = [];
  window.allDiplomas = [];

  window.nameSuggestionContainer = document.getElementById("titleSuggestions");
  window.keywordsSuggestionContainer = document.getElementById("keywordsSuggestions");
  window.studyfeildSuggestionContainer = document.getElementById("studySuggestionsContainer");
  window.diplomasSuggestionContainer = document.getElementById("diplomasSuggestionsContainer");


  
  //Number of results
  window.resultCount = document.getElementById("ResultsCount");

  window.searchTemplate = "orgunit_search_template"
  
  window.formElements = [
    "query_string", "name", "description", "type", "country", "city", "searchword", "studyfeild", "diplome", "language"
  ];

  /*
  window.relatedCode = {
    "langue": "code_langue_2"
  };
*/
  window.dropdownElements = {
    "type": "cdm_orgunit_5_2_orgunittype.text",
    "country": "cdm_orgunit_13_1_2_3_country",
    "city": "cdm_orgunit_13_1_2_2_city",
    "language": "cdm_orgunit_27_officiallanguage.lang",
    "description": "pr_cdm_description"
  };

  window.autoCompleteFields = {
    "name": "pr_cdm_name.text.completion",
    "searchword": "cdm_orgunit_17_searchword.completion",
    "studyfeild": "cdm_orgunit_24_studyfields.text.completion",
    "diplome": "cdm_orgunit_26_diplomas.text.completion"
  };

  //Suggestion containers event listener
  document.addEventListener('click', async (e) => {
    nameSuggestionContainer.style.display = "none";
    keywordsSuggestionContainer.style.display = "none";
    studyfeildSuggestionContainer.style.display = "none";
    diplomasSuggestionContainer.style.display = "none";
  });

  

  //console.log("JE SUIS LA");
  //Setting input listening events 
  addInputListener();

  addInputSuggestionListener();

  //TODO sorting 
  init();
  

  


  /*

  const fetchAndRenderAuthors = async () => {
    const authorInputValue = auteurInput.value;
    try {
      const authors = await searchAuthorService(authorInputValue);
      if (!authors) {
        return;
      }
      const authorHits = authors.hits.hits;
      renderSearchedAuthors(authorHits, auteurSuggestionsContainer, resultsContainer);
    } catch (error) {
      console.log(error);
    }
  };
  function debounce(func, delay) {
    let timeoutId;
    return function () {
      const context = this;
      const args = arguments;
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func.apply(context, args);
      }, delay);
    };
  }
  window.getAllRessourceWithCoposedRequest= async ()=>{
    resultsContainer.innerHTML ="<div class='loader'></div>";
      var auteurInputValue = auteurInput.value ; 
      var keyWordValue = keywordInput.value ;
      let titleInputValue = titleInput.value;
      var editorInputValue = editeurInput.value; 
      var sourceInputValue =  sourceInput.value;
      var typeInputValue =  typeInput.value;
      var langueInputValue =  langueInput.value;
      var  levelInputValue =  levelInput.value; 
      var  startInputValue =  startDateInput.value; 
      var  endInputValue =  endDateInput.value; 
      console.log('Title input ' ,titleInputValue );
      var requestBody = {
        query: {
          bool: {
            must: [],
          },
        },
      };
      requestBody.size = 12;
      requestBody.from = requestBody.size * (page-1) ; 
     
      requestBody.sort =  [
        {"id_document.keyword": "asc"}     
      ];
      if (sourceInputValue !== "") {
 
        requestBody.query.bool.must.push({
          match: {
            pr_source: sourceInputValue,
          },
        });
      }
      if (typeInputValue !== "") {
 
        requestBody.query.bool.must.push({
          match: {
            pr_resource_type: typeInputValue,
          },
        });
      }
      if(auteurInputValue!=''){
        requestBody.query.bool.must.push({
          match: {
          pr_resource_author: {
            query: auteurInputValue,
            operator: "and",
          },
        },
        });
      }
      if(keyWordValue!=''){
        requestBody.query.bool.must.push({
          match: {
            pr_resource_keyword: {
              query : keyWordValue,
              operator : "and",
            }
          },
        });
      }
      if(titleInputValue!=''){
        requestBody.query.bool.must.push({
          match: {
            pr_resource_title: {
              query : titleInputValue,
              operator : "and",
            }
          },
        });
      }
      if(editorInputValue!=''){
        requestBody.query.bool.must.push({
          match: {
            pr_resource_editor: {
              query : editorInputValue,
              operator :"and",
            }
          },
        });
      }
      if (langueInputValue !== "") {
 
        requestBody.query.bool.must.push({
          match: {
            pr_resource_language: langueInputValue,
          },
        });
      }
      if (levelInputValue !== "") {
 
        requestBody.query.bool.must.push({
          match_phrase: {
            pr_resource_level: levelInputValue,
          },
        });
      }
 
      if (startInputValue !== "") {
  
        requestBody.query.bool.must.push({
          range: {
            pr_modify_time: {
              "gte": startInputValue, 
              
            },
          },
        });
      }
 
      if (endInputValue !== "") {
  
        requestBody.query.bool.must.push({
          range: {
            pr_modify_time: {
              "lte": endInputValue, 
              
            },
          },
        });
      }

 
      try{
        const data = await fetchRessourceDate(requestBody) ; 
        const res = await data.json() ; 
        totalResult = res.hits.total.value;
        ResultsCount = res.hits.total.value;
        updateResultCounts();
        renderResourceCompleteTemplate(res) ; 
        console.log("help please",res);
      }catch(e){
        console.log("the error" , e);
      }
     
  }
  function updateResultCounts() {
    jQuery("#ResultsCount").text(ResultsCount);
 
    } 
  


  const debouncedKeywordInputHandler = debounce(async () => {
    let requestBody = createRequestBodyFunction();
    console.log("This is the request body:", requestBody);
    try {
      allKeyWords = [];
      const keywords = await searchKeywordService(requestBody);
      console.log("This is the response of keywords:", keywords);
      renderSearchedKeywords(keywords.hits.hits, keywordSuggestionsContainer);
      getAllResourceWithComposedRequest();
    } catch (error) {
      console.log(error);
    }
  }, 1000);

  const debouncedAuthorInputHandler = debounce(async () => {
    let requestBody = createRequestBodyFunction() ;  
    
    try{
      allAuteur = [] ; 
      const authors = await searchAuthorService(requestBody);
      console.log("authors response in input event listener:",authors)
      allAuteur = authors.hits.hits ; 
      renderSearchedAuthors(authors.hits.hits, auteurSuggestionsContainer);
      getAllRessourceWithCoposedRequest();
    
      }
      catch(error){
        console.log(error);
      }
  },1000);

  const debounceTitleInputHandler = debounce(async () => {
    let requestBody = createRequestBodyFunction() ;  
    console.log("requestBodyrequestBody",requestBody);
    try{
      allTitles = []  ; 
      const titles = await searchTitlesService(requestBody);
      getAllRessourceWithCoposedRequest();
      if(!titles){
        return ;
      }

      renderSearchedTitles(titles.hits.hits,titleSuggestionsContainer);

    }catch(error){
      console.log(error);
    }
  },1000)

  const debounceEditorInputHandler = debounce(async () => {
    let requestBody = createRequestBodyFunction() ; 
    try{
      allEditeur = [];
      const editeurs = await searchEditorsService(requestBody);

      renderSearchedEditeur(editeurs.hits.hits, editeurSuggestionsContainer);
      getAllRessourceWithCoposedRequest();
    }
    catch(error){
      console.log(error);
    }
  },1000)

  document.addEventListener('click' , async (e)=> {
    auteurSuggestionsContainer.style.display = "none";
    editeurSuggestionsContainer.style.display = "none";
    keywordSuggestionsContainer.style.display = "none";
    titleSuggestionsContainer.style.display = "none";
  })

  getAllRessourceWithCoposedRequest();
  auteurInput.addEventListener("keyup", debouncedAuthorInputHandler);
  auteurInput.addEventListener("click" ,async (e)=> {
    let requestBody = createRequestBodyFunction() ; 
    //const reqBody = createRequestBodyFunction();
    console.log("this is reque body " ,requestBody );
    console.log("request body In click author input listener",requestBody);
    try{
      allAuteur = [] ; 
      const authors = await searchAuthorService(requestBody);
  
      if(!authors){
        return ;
      }
      renderSearchedAuthors(authors.hits.hits, auteurSuggestionsContainer);
      }
      catch(error){
        console.log(error);
      }
  })
  
  
  
  auteurSuggestionsContainer.addEventListener("scroll", async () => {
    let requestBody = createRequestBodyFunction();   
    console.log('auteur scroll ',requestBody); 
   
      if (
        auteurSuggestionsContainer.scrollTop + auteurSuggestionsContainer.clientHeight >=
        auteurSuggestionsContainer.scrollHeight - 3 // Vous pouvez ajuster ce seuil selon vos besoins
      ) {
            
            try{
              const latestAuthor =  allAuteur[allAuteur.length - 1]; 
              //console.log(latestAuthor);
              const response = await getAuthorsService(requestBody,latestAuthor);
              console.log("this is response " ,response );
              renderAuthors(response.hits.hits,auteurSuggestionsContainer);
            }catch(e){
              console.log("there is error ", e);
            }
       

      }
   
  })

  keywordInput.addEventListener("keyup", debouncedKeywordInputHandler)

  keywordInput.addEventListener('click', async (e) => {
    e.stopPropagation();
    let requestBody = createRequestBodyFunction() ;     
    try{
      allKeyWords = [] ; 
      const keywords = await searchKeywordService(requestBody);
      console.log("keywords response in click event listeners:",keywords);
      if(!keywords){
        return ;
      }
      renderSearchedKeywords(keywords.hits.hits, keywordSuggestionsContainer);
      }
      catch(error){
        console.log(error);
      }
  })
  
  keywordSuggestionsContainer.addEventListener('scroll',async (e) => {
    let requestBody = createRequestBodyFunction() ;   
    console.log("scroll dans keyword suggestions")
    console.log("Hello");
    if (
      keywordSuggestionsContainer.scrollTop + keywordSuggestionsContainer.clientHeight >=
      keywordSuggestionsContainer.scrollHeight - 3 // Vous pouvez ajuster ce seuil selon vos besoins
    ) {
          
          try{
            let latestKeyWord =  allKeyWords[allKeyWords.length - 1]; 
            console.log("voila les keywords scrolling", latestKeyWord)
            const response = await getKeyWordScroll(requestBody,latestKeyWord);
            renderkeywords(response.hits.hits,keywordSuggestionsContainer);
          }catch(e){
            console.log("there is error ", e);
          }
    }
  })

// les editeurs
  editeurInput.addEventListener("input", debounceEditorInputHandler);

editeurInput.addEventListener('click', async (e) => {
  e.stopPropagation();
  let requestBody = createRequestBodyFunction() ;    
  try{
    allEditeur = [] ; 
    const editeurs = await searchEditorsService(requestBody);
    if(!editeurs){
      return ;
    }
    renderSearchedEditeur(editeurs.hits.hits, editeurSuggestionsContainer);
    }
    catch(error){
      console.log(error);
    }
})
 
editeurSuggestionsContainer.addEventListener('scroll',async () => {
  
  if (
    editeurSuggestionsContainer.scrollTop + editeurSuggestionsContainer.clientHeight >=
    editeurSuggestionsContainer.scrollHeight - 3 // Vous pouvez ajuster ce seuil selon vos besoins
  ) {
    let requestBody = createRequestBodyFunction() ;  
        
        try{
          let latestEditeur =  allEditeur[allEditeur.length - 1]; 
          const response = await getEditorsService(requestBody,latestEditeur);
          renderEditeurs(response.hits.hits,editeurSuggestionsContainer);
        }catch(e){
          console.log("there is error ", e);
        }
  }
})



  titleInput.addEventListener("input", debounceTitleInputHandler)

  titleInput.addEventListener("click",async () => {
    let requestBody = createRequestBodyFunction() ;  
    try{
      const titles = await searchTitlesService(requestBody);

      if(!titles){
        return ;
      }

      renderSearchedTitles(titles.hits.hits,titleSuggestionsContainer);

    }catch(error){
      console.log(error);
    }
  })

  titleSuggestionsContainer.addEventListener('scroll', async () => {
    let requestBody = createRequestBodyFunction() ;  
    if (
      titleSuggestionsContainer.scrollTop + titleSuggestionsContainer.clientHeight >=
      titleSuggestionsContainer.scrollHeight - 3 // Vous pouvez ajuster ce seuil selon vos besoins
    ) {
          
          try{
            const latestTitle =  allTitles[allTitles.length - 1]; 
            const response = await getTitlesService(requestBody,latestTitle);
            console.log('this is response ',response );
            renderTitles(response.hits.hits,titleSuggestionsContainer);
          }catch(e){
            console.log("there is error ", e);
          }
    }
  })
  sourceInput.addEventListener('change' , (e)=>{
    page=1 ; 
    getAllRessourceWithCoposedRequest();
  })

  typeInput.addEventListener('change' , (e)=>{
    page=1 ; 
    getAllRessourceWithCoposedRequest();
  })

  langueInput.addEventListener('change' , (e)=>{
    page=1 ; 
    getAllRessourceWithCoposedRequest();
  })

  levelInput.addEventListener('change' , (e)=>{
    page=1 ; 
    getAllRessourceWithCoposedRequest();
  })
  startDateInput.addEventListener('input' , (e)=>{
    page=1 ; 
    getAllRessourceWithCoposedRequest();
  })
  endDateInput.addEventListener('input' , (e)=>{
    page=1 ; 
    getAllRessourceWithCoposedRequest();
  })*/
}







